#Install devtools
install.packages("devtools")

#Load the devtools
library(devtools)

#check the version of the package
packageVersion("devtools")

#create package
create_package("E:/WWU-2nd Semester/SPATIAL DATA SCIENCE WITH R/R_ToyPackage/regexcite")

library(regexcite)

x <- "alfa,bravo,charlie,delta"
strsplit1(x, split = ",")
