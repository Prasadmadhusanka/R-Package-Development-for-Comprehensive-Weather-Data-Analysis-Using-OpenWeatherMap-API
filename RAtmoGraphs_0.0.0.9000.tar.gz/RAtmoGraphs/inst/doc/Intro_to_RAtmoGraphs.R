## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## -----------------------------------------------------------------------------
library(RAtmoGraphs)

## -----------------------------------------------------------------------------
#Generate data frame for 'tempurature'
get_weather_data("temperature")

## -----------------------------------------------------------------------------
#Density heat map of temperature for the nearest 50 locations from the user's location
map_tempurature_data()

## -----------------------------------------------------------------------------
#Dot Density map for humidity for the nearest 50 locations from the user's location
map_humidity_data()

## -----------------------------------------------------------------------------
#Dot Density map for wind speed for the nearest 50 locations from the user's location
map_windspeed_data()

