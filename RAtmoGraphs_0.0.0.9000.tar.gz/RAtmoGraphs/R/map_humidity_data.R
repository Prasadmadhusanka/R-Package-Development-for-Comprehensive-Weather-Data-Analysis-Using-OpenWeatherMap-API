
#' Visualization of humidity data through openweatherMap API
#'
#' @return humidity map
#' @export
#'
#' @examples
#' map_humidity_data
map_humidity_data <- function(){

  # Get user's current location using IP geolocation

  response <- httr::GET("https://ipinfo.io")
  if (httr::status_code(response) == 200) {
    location_data <- httr::content(response, as = "parsed")
    lat_lon <- strsplit(location_data$loc, ",")
    latitude <- as.numeric(lat_lon[[1]][1])
    longitude <- as.numeric(lat_lon[[1]][2])
    user_location <- c(latitude, longitude)
    print("Your current location is:")
    print(user_location)
  } else {
    print("Error retrieving user's location.")
    return(NULL)
  }

  # Define parameters
  lat <- latitude
  lon <- longitude
  count <- 50
  api_key <- "ccf999d2a1431ea4c6683a971d888799"

  # Construct the URL
  main_url <- "http://api.openweathermap.org/data/2.5/find"
  query_params <- list(lat = lat, lon = lon, cnt = count, appid = api_key, units = "metric")

  # Make the API request
  response <- httr::GET(url = main_url, query = query_params)

  # Check response status and process data
  if (httr::status_code(response) == 200) {
    weather_data <- httr::content(response, as = "parsed")$list
  } else {
    print("Error for receiving weather data from OpenWeatherMap.")
    return(NULL)
  }

  weather_dataframe_hu <-  data.frame(
    StationName = character(),
    Latitude = numeric(),
    Longitude = numeric(),
    Humidity = numeric(),
    Description = character(),
    stringsAsFactors = FALSE
  )

  # Append humidity data for each station to the data frame
  if (!is.null(weather_data)) {
    for (station in weather_data) {
      weather_dataframe_hu <- rbind(weather_dataframe_hu,
                                    c(station$name, station$coord$lat, station$coord$lon, station$main$humidity, station$weather[[1]]$description)
      )
    }
  } else {
    cat("No weather data avilable")
  }

  # Change column names in the weather_df data frame
  colnames(weather_dataframe_hu) <- c("Station_Name", "Latitude", "Longitude", "humidity","Weather_Description")

  #change humidity values in to integer values
  weather_dataframe_hu$humidity <- as.integer(weather_dataframe_hu$humidity)

  #change coordinates in to numeric values
  weather_dataframe_hu$Latitude <- as.numeric(weather_dataframe_hu$Latitude)
  weather_dataframe_hu$Longitude <- as.numeric(weather_dataframe_hu$Longitude)

  # Calculate the central point of latitude and longitude
  central_lat <- mean(weather_dataframe_hu$Latitude)
  central_lon <- mean(weather_dataframe_hu$Longitude)

  # Define a color palette for the humidity values
  color_palette <- leaflet::colorNumeric(palette = "Blues", domain = weather_dataframe_hu$humidity)

  # Create a leaflet map for humidity data
  my_Humi_map <- leaflet::leaflet(weather_dataframe_hu)
  # Set the initial view of the map
  my_Humi_map <- leaflet::setView(my_Humi_map,lng = central_lon, lat = central_lat, zoom = 10)
  # Add the base map tiles
  my_Humi_map <- leaflet::addTiles(my_Humi_map)
  my_Humi_map <- leaflet::addCircleMarkers(my_Humi_map,
        lng = weather_dataframe_hu$Longitude,
        lat = weather_dataframe_hu$Latitude,
        radius = weather_dataframe_hu$humidity * 0.2,  # Scale radius based on humidity
        color = color_palette(weather_dataframe_hu$humidity),
        fillOpacity = 0.5,
        # Set the popup content to display the humidity value
        popup = ~paste("The humidity value of ",weather_dataframe_hu$Station_Name," is ",weather_dataframe_hu$humidity,"%")
  )

  # Display the map
  my_Humi_map
}

map_humidity_data()
