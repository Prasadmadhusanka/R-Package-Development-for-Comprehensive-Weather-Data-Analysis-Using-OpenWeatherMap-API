
#' Visualization of temperature data through openweatherMap API
#'
#' @return temperature map
#' @export
#'
#' @examples
#' map_tempurature_data()
map_tempurature_data <- function(){

  # Get user's current location using IP geolocation

  response <- httr::GET("https://ipinfo.io")
  if (httr::status_code(response) == 200) {
    location_data <- httr::content(response, as = "parsed")
    lat_lon <- strsplit(location_data$loc, ",")
    latitude <- as.numeric(lat_lon[[1]][1])
    longitude <- as.numeric(lat_lon[[1]][2])
    user_location <- c(latitude, longitude)
    print("Your current location is:")
    print(user_location)
  } else {
    print("Error retrieving user's location.")
    return(NULL)
  }

  # Define parameters
  lat <- latitude
  lon <- longitude
  count <- 50
  api_key <- "ccf999d2a1431ea4c6683a971d888799"

  # Construct the URL
  main_url <- "http://api.openweathermap.org/data/2.5/find"
  query_params <- list(lat = lat, lon = lon, cnt = count, appid = api_key, units = "metric")

  # Make the API request
  response <- httr::GET(url = main_url, query = query_params)

  # Check response status and process data
  if (httr::status_code(response) == 200) {
    weather_data <- httr::content(response, as = "parsed")$list
  } else {
    print("Error for receiving weather data from OpenWeatherMap.")
    return(NULL)
  }

  # Create a data frame to store the tempurature data
  weather_dataframe <-  data.frame(
    StationName = character(),
    Latitude = numeric(),
    Longitude = numeric(),
    Temperature = numeric(),
    Description = character(),
    stringsAsFactors = FALSE
  )

  # Append temperature data for each station to the data frame
  if (!is.null(weather_data)) {
    for (station in weather_data) {
      weather_dataframe <- rbind(weather_dataframe,
                                 c(station$name, station$coord$lat, station$coord$lon, station$main$temp, station$weather[[1]]$description)
      )
    }
  } else {
    cat("No weather data avilable")
  }

  # Change column names in the weather_df data frame
  colnames(weather_dataframe) <- c("Station_Name", "Latitude", "Longitude", "temp","Weather_Description")

  #change tempurature values in to integers
  weather_dataframe$temp <- as.integer(weather_dataframe$temp)

  #change coordinates in to numeric values
  weather_dataframe$Latitude <- as.numeric(weather_dataframe$Latitude)
  weather_dataframe$Longitude <- as.numeric(weather_dataframe$Longitude)

  # Calculate the central point of latitude and longitude
  central_lat <- mean(weather_dataframe$Latitude)
  central_lon <- mean(weather_dataframe$Longitude)

  # Create a leaflet map for tempurature data
  my_temp_map <- leaflet::leaflet(weather_dataframe)
  # Set the initial view of the map
  my_temp_map <- leaflet::setView(my_temp_map,lng = central_lon, lat = central_lat, zoom = 10)
  # Add the base map tiles
  my_temp_map <- leaflet::addTiles(my_temp_map)
  # Add heatmap layer
  my_temp_map <- leaflet.extras::addHeatmap(my_temp_map,lng = ~Longitude, lat = ~Latitude, intensity = ~temp)

  # Display the map
  my_temp_map
}


