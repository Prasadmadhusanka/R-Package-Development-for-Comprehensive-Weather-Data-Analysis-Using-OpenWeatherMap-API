#' Create data frames for weather data through openweatherMap API
#'
#' @param parameter {"temperature","humidity","wind speed"}
#'
#' @return Create data frames
#' @export
#'
#' @examples
#' parameter <- "temperature"
#' get_weather_data(parameter)
get_weather_data <- function(parameter){


  # Function to get user's current location using IP geolocation

  response <- httr::GET("https://ipinfo.io")
  if (httr::status_code(response) == 200) {
    location_data <- httr::content(response, as = "parsed")
    lat_lon <- strsplit(location_data$loc, ",")
    latitude <- as.numeric(lat_lon[[1]][1])
    longitude <- as.numeric(lat_lon[[1]][2])
    user_location <- c(latitude, longitude)
    print("Your current location is:")
    print(user_location)
  } else {
    print("Error retrieving user's location.")
    return(NULL)
  }

  # Define parameters
  lat <- latitude
  lon <- longitude
  count <- 50
  api_key <- "ccf999d2a1431ea4c6683a971d888799"

  # Construct the URL
  main_url <- "http://api.openweathermap.org/data/2.5/find"
  query_params <- list(lat = lat, lon = lon, cnt = count, appid = api_key, units = "metric")

  # Make the API request
  response <- httr::GET(url = main_url, query = query_params)

  # Check response status and process data
  if (httr::status_code(response) == 200) {
    weather_data <- httr::content(response, as = "parsed")$list
  } else {
    print("Error for receiving weather data from OpenWeatherMap.")
    return(NULL)
  }

  # Create a data frame for tempurature to store the weather data
  if(parameter == "temperature"){
    weather_dataframe <-  data.frame(
      StationName = character(),
      Latitude = numeric(),
      Longitude = numeric(),
      Temperature = numeric(),
      Description = character(),
      stringsAsFactors = FALSE
    )

    # Append weather data for each station to the data frame
    if (!is.null(weather_data)) {
      for (station in weather_data) {
        weather_dataframe <- rbind(weather_dataframe,
                                   c(station$name, station$coord$lat, station$coord$lon, station$main$temp, station$weather[[1]]$description)
        )
      }
    } else {
      cat("No weather data avilable")
    }

    # Change column names in the weather_df data frame
    colnames(weather_dataframe) <- c("Station_Name", "Latitude", "Longitude", "temp","Weather_Description")

    # Print the data frame with updated column names
    print(weather_dataframe)

    #make data frame for humidity values

  }else if(parameter == "humidity"){
    weather_dataframe_hu <-  data.frame(
      StationName = character(),
      Latitude = numeric(),
      Longitude = numeric(),
      Humidity = numeric(),
      Description = character(),
      stringsAsFactors = FALSE
    )

    # Append weather data for each station to the data frame
    if (!is.null(weather_data)) {
      for (station in weather_data) {
        weather_dataframe_hu <- rbind(weather_dataframe_hu,
                                      c(station$name, station$coord$lat, station$coord$lon, station$main$humidity, station$weather[[1]]$description)
        )
      }
    } else {
      cat("No weather data avilable")
    }

    # Change column names in the weather_df data frame
    colnames(weather_dataframe_hu) <- c("Station_Name", "Latitude", "Longitude", "humidity","Weather_Description")

    # Print the data frame with updated column names
    print(weather_dataframe_hu)

    #make dataframe for wind speed values
  }else if(parameter == "wind speed"){
    weather_dataframe_w <-  data.frame(
      StationName = character(),
      Latitude = numeric(),
      Longitude = numeric(),
      Windspeed = numeric(),
      Description = character(),
      stringsAsFactors = FALSE
    )

    # Append weather data for each station to the data frame
    if (!is.null(weather_data)) {
      for (station in weather_data) {
        weather_dataframe_w <- rbind(weather_dataframe_w,
                                     c(station$name, station$coord$lat, station$coord$lon, station$wind$speed, station$weather[[1]]$description)
        )
      }
    } else {
      cat("No weather data avilable")
    }

    # Change column names in the weather_df data frame
    colnames(weather_dataframe_w) <- c("Station_Name", "Latitude", "Longitude", "wind speed","Weather_Description")

    # Print the data frame with updated column names
    print(weather_dataframe_w)
  }


}
