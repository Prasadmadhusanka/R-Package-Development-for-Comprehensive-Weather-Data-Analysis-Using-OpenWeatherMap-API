#' Visualization of wind data through openweatherMap API
#'
#' @return wind speed map
#' @export
#'
#' @examples
#' map_windspeed_data()
map_windspeed_data <- function(){

  # Get user's current location using IP geolocation

  response <- httr::GET("https://ipinfo.io")
  if (httr::status_code(response) == 200) {
    location_data <- httr::content(response, as = "parsed")
    lat_lon <- strsplit(location_data$loc, ",")
    latitude <- as.numeric(lat_lon[[1]][1])
    longitude <- as.numeric(lat_lon[[1]][2])
    user_location <- c(latitude, longitude)
    print("Your current location is:")
    print(user_location)
  } else {
    print("Error retrieving user's location.")
    return(NULL)
  }

  # Define parameters
  lat <- latitude
  lon <- longitude
  count <- 50
  api_key <- "ccf999d2a1431ea4c6683a971d888799"

  # Construct the URL
  main_url <- "http://api.openweathermap.org/data/2.5/find"
  query_params <- list(lat = lat, lon = lon, cnt = count, appid = api_key, units = "metric")

  # Make the API request
  response <- httr::GET(url = main_url, query = query_params)

  # Check response status and process data
  if (httr::status_code(response) == 200) {
    weather_data <- httr::content(response, as = "parsed")$list
  } else {
    print("Error for receiving weather data from OpenWeatherMap.")
    return(NULL)
  }

  weather_dataframe_w <-  data.frame(
    StationName = character(),
    Latitude = numeric(),
    Longitude = numeric(),
    Windspeed = numeric(),
    Description = character(),
    stringsAsFactors = FALSE
  )

  # Append wind speed data for each station to the data frame
  if (!is.null(weather_data)) {
    for (station in weather_data) {
      weather_dataframe_w <- rbind(weather_dataframe_w,
                                   c(station$name, station$coord$lat, station$coord$lon, station$wind$speed, station$weather[[1]]$description)
      )
    }
  } else {
    cat("No weather data avilable")
  }

  # Change column names in the weather_df data frame
  colnames(weather_dataframe_w) <- c("Station_Name", "Latitude", "Longitude", "wind_speed","Weather_Description")

  #change wind speed data in to integer
  weather_dataframe_w$wind_speed <- as.integer(weather_dataframe_w$wind_speed)

  #change coordintes in to numeric values
  weather_dataframe_w$Latitude <- as.numeric(weather_dataframe_w$Latitude)
  weather_dataframe_w$Longitude <- as.numeric(weather_dataframe_w$Longitude)

  # Calculate the central point of latitude and longitude
  central_lat <- mean(weather_dataframe_w$Latitude)
  central_lon <- mean(weather_dataframe_w$Longitude)

  # Define a color palette for the humidity values
  color_palette <- leaflet::colorNumeric(palette = "Reds", domain = weather_dataframe_w$wind_speed)

  # Create a leaflet map for wind speed
  my_win_map <- leaflet::leaflet(weather_dataframe_w)
  # Set the initial view of the map
  my_win_map <- leaflet::setView(my_win_map, lng = central_lon, lat = central_lat, zoom = 10)
  # Add the base map tiles
  my_win_map <- leaflet::addTiles(my_win_map)
  my_win_map <- leaflet::addCircleMarkers(my_win_map,
        lng = weather_dataframe_w$Longitude,
        lat = weather_dataframe_w$Latitude,
        radius = weather_dataframe_w$wind_speed * 5,  # Scale radius based on wind speed
        color = color_palette(weather_dataframe_w$wind_speed),
        fillOpacity = 0.5,
        # Set the popup content to display the wind speed value
        popup = ~paste("The wind speed value of ",weather_dataframe_w$Station_Name," is ",weather_dataframe_w$wind_speed,"m/s")
  )

  # Display the map
  my_win_map

}

map_windspeed_data()
